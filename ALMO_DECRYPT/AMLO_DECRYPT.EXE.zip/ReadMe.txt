พัฒนาด้วย .Net Core Version 3.1
เครื่องที่ใช้ต้องลง .Net Core Version 3.1 สามารถ download 
ได้ที่ Link ด้านล่าง
https://dotnet.microsoft.com/download/dotnet/3.1 